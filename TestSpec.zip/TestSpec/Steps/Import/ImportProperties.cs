using AngleSharp.Dom;
using Eviivo.Suite.Spec.Helpers;
using NUnit.Framework;
using TechTalk.SpecFlow;

namespace Eviivo.Suite.Spec.Steps.Login;

[Binding]
public class ImportProperties
{
    [Then(@"I should see the import properties page tiles")]
    public void ThenIShouldSeeTheImportPropertiesPageTiles()
    {
        var elementFound = SeleniumHelper.ElementExists("property-mapping");
        Assert.That(elementFound, Is.True, "the import property title was not found.");
    }

    [Given(@"I press the search button")]
    public void WhenIPressTheSearchButton()
    {
        SeleniumHelper.PressButtonWithId("btnRefresh");
    }

    [Given(@"I press the view link")]
    public void WhenIPressTheViewLink()
    {
        Thread.Sleep(1000);
        SeleniumHelper.PressButtonWithClass("view-pms-as-me");
    }
    
    [Then(@"I should see the import properties title ""(.*)""")]
    public void ThenIShouldSeeTheImportPropertiesTile(string title)
    {
        SeleniumHelper.ClassContainsText("s-property-mapping",title);
    }
        
    [Then(@"I should see the import properties sub title ""(.*)""")]
    public void ThenIShouldSeeTheImportPropertiesSubTile(string title)
    {
        SeleniumHelper.ClassContainsText("s-property-mapping",title);
    }
        
    [Then(@"I should see ""(.*)"" elements ""(.*)""")]
    public void ThenIShouldSeeElements(int collapsableNo, string className)
    {
        var elements = SeleniumHelper.GetElementsByClass(className);
        Assert.That(elements.Count, Is.EqualTo(collapsableNo));
    }
        
    [Then(@"I should see ""(.*)"" elements ""(.*)"" with lable ""(.*)""")]
    public void ThenIShouldSeeElementsWithLabel(int collapsableNo, string className, string text)
    {
        var elements = SeleniumHelper.GetElementsByClass(className);
        Assert.That(elements.Count, Is.EqualTo(collapsableNo));
        // foreach(var element in elements){
        //     Assert.That(element.Text, Is.EqualTo(text));
        // }
    }


}
