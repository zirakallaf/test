using System;
using Eviivo.Suite.Spec.Helpers;
using NUnit.Framework;
using TechTalk.SpecFlow;

namespace Eviivo.Suite.Spec.Steps;

/// <summary>
/// Class to contain the steps that are used in common between all tests.
/// </summary>
[Binding]
public class GeneralSteps
{
    /// <summary>
    /// Variable to hold the scenario context for test interrogation.
    /// </summary>
    private readonly ScenarioContext _scenarioContext;

    /// <summary>
    /// Default site hit if no setting file is set.
    /// </summary>
    private readonly string defaultRoot = "https://qa5-on.eviivo.com/";

    /// <summary>
    /// Default browser used if no setting file is set.
    /// </summary>
    private readonly string defaultBrowser = "Chrome";

    /// <summary>
    /// Class override setting the scenario context.
    /// </summary>
    public GeneralSteps(ScenarioContext scenarioContext)
    {
        _scenarioContext = scenarioContext;
    }

    [BeforeScenario()]
    public void StartSeleniumTest()
    {
        string? browser = TestContext.Parameters["browser"];
        browser ??= defaultBrowser;
        SeleniumHelper.SetBrowserDriver(browser);
    }

    [AfterScenario()]
    public static void EndSeleniumTest()
    {
        SeleniumHelper.CloseBrowser();
    }


    [Given(@"I have a browser window")]
    public void GivenIhaveabrowserwindow()
    {
        Assert.That(SeleniumHelper.HasBrowserDriver(), Is.True);
    }

    [Given(@"I have logged in as ""(.*)"" with password ""(.*)""")]
    [When(@"I log in as ""(.*)"" with password ""(.*)""")]
    public void GivenIHaveLoggedInWithPassword(string username, string password)
    {
        string root = TestContext.Parameters["baseURL"] ?? defaultRoot;
        SeleniumHelper.GotoURL(root);
        SeleniumHelper.EnterTextIntoControl("txtUserName", username);
        SeleniumHelper.EnterTextIntoControl("txtPassword", password);
        SeleniumHelper.PressButtonWithId("btnLogin");
        // // Wait for the login process to complete and the home page to load.
        // SeleniumHelper.WaitForElementByClass("v-toolbar-title");
    }

    [When(@"I log out and log in again as ""(.*)"" with password ""(.*)""")]
    public void WhenILogOutAndLogInAgainAsWithPassword(string username, string password)
    {
        WhenINavigateTo("logout");
        GivenIHaveLoggedInWithPassword(username, password);
    }


    [Given(@"I navigate to ""(.*)""")]
    [When(@"I navigate to ""(.*)""")]
    public void WhenINavigateTo(string uri)
    {
        SeleniumHelper.NavigateTo(uri);
    }

    [Then(@"I should see an element with id ""(.*)""")]
    public void ThenIShouldSeeAnElementWithId(string id)
    {
        SeleniumHelper.TestElementById(id);
    }

    [Given(@"I should see eviivo logo")]
    public void GivenIShouldSeeEviivoLogo()
    {
        SeleniumHelper.WaitForElementByClass("cp-logo");
    }

    [Given(@"I should see view link")]
    public void GivenIShouldSeeViewLink()
    {
        SeleniumHelper.WaitForElementByClass("view-pms-as-me");
    }


    [Given(@"I access the website")]
    [When(@"I access the website")]
    public void WhenIAccessTheWebsite()
    {
        string root = TestContext.Parameters["baseURL"] ?? defaultRoot;
        Assert.That(root, Is.Not.Empty);
        SeleniumHelper.GotoURL(root);
    }

    [Given(@"I have entered ""(.*)"" into the field ""(.*)""")]
    [When(@"I have entered ""(.*)"" into the field ""(.*)""")]
    public void WhenIHaveEnteredIntoTheField(string value, string elementId)
    {
        SeleniumHelper.EnterTextIntoControl(elementId, value);
    }
    
    [When(@"I navigate to import properties ""(.*)""")]
    public void WhenINavigateToImportPropertiesAirbnb(string ota)
    {
        string root = TestContext.Parameters["baseURL"] ?? defaultRoot;
        SeleniumHelper.GotoURL($"{root}suite/ImportProperties/{ota}");
    }
    

}




