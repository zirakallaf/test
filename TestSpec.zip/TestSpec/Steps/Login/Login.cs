using Eviivo.Suite.Spec.Helpers;
using TechTalk.SpecFlow;

namespace Eviivo.Suite.Spec.Steps.Login;

[Binding]
public class Login
{
    
    [When(@"I press the login button")]
    public void WhenIPressTheLoginButton()
    {
        SeleniumHelper.PressButtonWithId("btnLogin");
    }
}