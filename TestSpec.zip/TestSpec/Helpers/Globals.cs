using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;

namespace Eviivo.Suite.Spec.Helpers
{
    /// <summary>
    /// The main class for the global parameters used in the Selenium test project.
    /// <summary>
    public static class Globals
    {
        /// <summary>
        /// The main webdriver instance that is used for all the tests.
        /// <summary>
        public static IWebDriver Driver;
        
        /// <summary>
        /// The wait parameter used to initiate delays between tests.
        /// <summary>
        public static WebDriverWait Wait;
        
    }
}

