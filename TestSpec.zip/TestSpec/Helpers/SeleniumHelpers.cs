using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Edge;
using OpenQA.Selenium.Firefox;
using WebDriverManager.DriverConfigs.Impl;

namespace Eviivo.Suite.Spec.Helpers;

/// <summary>
/// The main class containing the site level selenium help routines.
/// <summary>

public static class SeleniumHelper
{
    /// <summary>
    /// Creates a specific browser instance for the tests to perform on.
    /// <summary>
    /// <param name="browser">The name of the browser to create for the test.</param>
    ///<returns>void</returns>
    /// <remarks>
    /// The current brwoser values accepted are:
    /// 1.  Edge
    /// 2.  Chrome
    /// 3.  Firefox
    /// </remarks>
    public static void SetBrowserDriver(string browser)
    {
        switch (browser)
        {
            case "Edge":
                new WebDriverManager.DriverManager().SetUpDriver(new EdgeConfig());
                var edgeOptions = new EdgeOptions();
                Globals.Driver = new EdgeDriver(
                    EdgeDriverService.CreateDefaultService(),
                    edgeOptions,
                    TimeSpan.FromMinutes(2)
                );
                break;
            case "Chrome":
                new WebDriverManager.DriverManager().SetUpDriver(new ChromeConfig());
                var chromeOptions = new ChromeOptions();
                chromeOptions.AddArgument("start-maximized");
                chromeOptions.AddArgument("no-sandbox");
                Globals.Driver = new ChromeDriver(
                    ChromeDriverService.CreateDefaultService(),
                    chromeOptions,
                    TimeSpan.FromSeconds(50)
                    // TimeSpan.FromMinutes(20)
                );
                break;
            case "Firefox":
                new WebDriverManager.DriverManager().SetUpDriver(new FirefoxConfig());
                FirefoxOptions firefoxOptions = new FirefoxOptions();
                firefoxOptions.AddArgument("--width=960");
                firefoxOptions.AddArgument("--height=1000");
                //firefoxOptions.AddArgument("--top=0");
                //firefoxOptions.AddArgument("--left=0");
                firefoxOptions.AddArgument("no-sandbox");
                Globals.Driver = new FirefoxDriver(
                    FirefoxDriverService.CreateDefaultService(),
                    firefoxOptions,
                    TimeSpan.FromMinutes(2)
                );
                break;
        }
        Globals.Driver.Manage().Timeouts().PageLoad.Add(TimeSpan.FromSeconds(30));
        Globals.Driver.Manage().Timeouts().ImplicitWait = new TimeSpan(0, 0, 3);
    }
    
    /// <summary>
    /// Determines if the browser driver is created or not.
    /// <summary>
    ///<returns>True if the driver is not null</returns>
    public static bool HasBrowserDriver()
    {
        return Globals.Driver != null;
    }
    /// <summary>
    /// Closes the browser and disposes of the object.
    /// <summary>
    ///<returns>void</returns>
    [TearDown]
    public static void CloseBrowser()
    {
        Globals.Driver.Close();
        Globals.Driver.Quit();
    }

    /// <summary>
    /// Navigates to a spacific url
    /// <summary>
    /// <param name="url">The url to navigate to.</param>
    ///<returns>void</returns>
    public static void GotoURL(string url)
    {
        Assert.Multiple(() =>
        {
            Assert.That(url, Is.Not.Null, "No url string was provided.");
            Assert.That(url, Is.Not.Empty,"The url string was provided as an empty string.");
        });
        Globals.Driver.Navigate().GoToUrl(url);
    }

    /// <summary>
    /// Navigates to a spacific page uri using the side navigation bar.
    /// <summary>
    /// <param name="uri">The uri to navigate to.</param>
    ///<returns>void</returns>
    public static void NavigateTo(string uri)
    {
        Assert.Multiple(() =>
        {
            Assert.That(uri, Is.Not.Null, "No uri string was provided.");
            Assert.That(uri, Is.Not.Empty, "The uri string was provided as an empty string.");
        });
        // WaitForElementToDisappearByClass("pg-loading-center-middle");
        // var container = GetElementFromId("sidebarContainer");
        var container = GetFirstElementFromClass("l-container");
        var elems = GetTagsFromElement(container, "a"); // Globals.Driver.FindElements(By.TagName("a"));
        foreach (var elem in elems)
        {
            var href = elem.GetAttribute("href");
            if (href != null)
            {
                if (href.Contains(uri))
                {
                    elem.Click();
                    return;
                }
            }
        }
    }
    
    /// <summary>
    /// Checks the page for the title provided.
    /// <summary>
    /// <param name="title">The title of the page to check.</param>
    ///<returns>void</returns>
    public static void TestPageTitle(string title)
    {
        Assert.Multiple(() =>
        {
            Assert.That(title, Is.Not.Null, "No page title was provided.");
            Assert.That(title , Is.Not.Empty, "The page title was provided as an empty string.");
            Assert.That(Globals.Driver.Title, Is.EqualTo(title),
            string.Concat(
                "The title of the page navigated to was ",
                Globals.Driver.Title,
                " not ",
                title
            ),
            null
        );
        });
    }
    /// <summary>
    /// Checks the an element with the id provided exists on the page.
    /// <summary>
    /// <param name="id">The id of the element to check.</param>
    ///<returns>void</returns>
    public static void TestElementById(string id)
    {
        Assert.Multiple(() =>
        {
            Assert.That(id, Is.Not.Null, "No id was provided.");
            Assert.That(id, Is.Not.Empty, "The id was provided as an empty string.");
        });
        var elems = Globals.Driver.FindElements(By.Id(id));
        Assert.That(
            elems, Is.Not.Empty,
            string.Concat("No elements of id ", id, " were found at ", Globals.Driver.Url),
            null
        );
    }
    /// <summary>
    /// Checks that an element corresponding to the id provided exists on the page.
    /// <summary>
    /// <param name="id">The id of the element to check.</param>
    ///<returns>True if the element exists</returns>
    public static bool ElementExists(string id)
    {
        Assert.Multiple(() =>
        {
            Assert.That(id, Is.Not.Null, "No id was provided.");
            Assert.That(id, Is.Not.Empty, "The id was provided as an empty string.");
        });
        var elems = Globals.Driver.FindElements(By.Id(id));
        return elems.Count > 0;
    }
    /// <summary>
    /// Checks that an element corresponding to the id provided does not exist on the page.
    /// <summary>
    /// <param name="id">The id of the element to check.</param>
    ///<returns>True if the element does not exist</returns>
    public static bool ElementNotExists(string id)
    {
        Assert.That(id, Is.Not.Null, "No id was provided.");
        Assert.That(id, Is.Not.Empty, "The id was provided as an empty string.");
        var elems = Globals.Driver.FindElements(By.Id(id));
        return elems.Count == 0;
    }
    /// <summary>
    /// Checks that an element corresponding to the class name provided exists on the page.
    /// <summary>
    /// <param name="className">The class name of the element to check.</param>
    ///<returns>True if the element exists</returns>
    public static bool ClassExists(string className)
    {
        Assert.That(className, Is.Not.Null, "No class name was provided.");
        Assert.That(className, Is.Not.Empty, "The class name was provided as an empty string.");
        var elems = Globals.Driver.FindElements(By.ClassName(className));
        return elems.Count > 0;
    }
    /// <summary>
    /// Checks that an element corresponding to the class name provided does not exist on the page.
    /// <summary>
    /// <param name="className">The class name of the element to check.</param>
    ///<returns>True if the element does not exist</returns>
    public static bool ClassNotExists(string className)
    {
        Assert.Multiple(() =>
        {
            Assert.That(className, Is.Not.Null, "No class name was provided.");
            Assert.That( className, Is.Not.Empty, "The class name was provided as an empty string.");
        });
        var elems = Globals.Driver.FindElements(By.ClassName(className));
        return elems.Count == 0;
    }
    /// <summary>
    /// Checks the the element provided contains the text provided.
    /// <summary>
    /// <param name="elem">The id of the element to check.</param>
    /// <param name="text">The text of the element to check.</param>
    ///<returns>void</returns>
    public static void ElementContainsText(IWebElement elem, string text)
    {
        Assert.Multiple(() =>
        {
            Assert.That(elem, Is.Not.Null, "No element was provided.");
            Assert.That(text, Is.Not.Null, "No text was provided.");
        });
        Assert.That(text, Is.Not.Empty, "The text was provided as an empty string.");
        var txt = elem.Text;
        if (txt.Length == 0)
        {
            Assert.That(elem.GetAttribute("value"), Does.Contain(text),
                "The text contained in the element did not match the text " + text);
        }
        else
        {
            Assert.That( txt, Does.Contain(text),
                "The text contained in the element did not match the text " + text
            );
        }
    }
    /// <summary>
    /// Checks the an element with the id provided contains the text provided.
    /// <summary>
    /// <param name="id">The id of the element to check.</param>
    /// <param name="text">The text of the element to check.</param>
    ///<returns>void</returns>
    public static void ElementContainsText(string id, string text)
    {
        Assert.Multiple(() =>
        {
            Assert.That(id, Is.Not.Null, "No element id was provided.");
            Assert.That(text, Is.Not.Null, "No text was provided.");
        });
        Assert.Multiple(() =>
        {
            Assert.That(id, Is.Not.Empty, "The element id was provided as an empty string.");
            Assert.That(text, Is.Not.Empty, "The text was provided as an empty string.");
        });
        var ctl = Globals.Driver.FindElement(By.Id(id));
        Assert.That(
            ctl, Is.Not.Null,
            "The element with id " + id + " could not be found on the current page"
        );
        var txt = ctl.Text;
        if (txt.Length == 0)
        {
            Assert.That(
                ctl.GetAttribute("value"), Does.Contain(text),
                "The text contained in the element with id "
                    + id
                    + " did not match the text "
                    + text
            );
        }
        else
        {
            Assert.That(
                txt, Does.Contain(text),
                "The text contained in the element with id "
                    + id
                    + " did not match the text "
                    + text
            );
        }
    }
    /// <summary>
    /// Checks the an element with the class provided contains the text provided.
    /// <summary>
    /// <param name="elementClass">The class of the element to check.</param>
    /// <param name="text">The text of the element to check.</param>
    ///<returns>void</returns>
    public static void ClassContainsText(string elementClass, string text)
    {
        Assert.Multiple(() =>
        {
            Assert.That(elementClass, Is.Not.Null, "No element class was provided.");
            Assert.That(text, Is.Not.Null, "No text was provided.");
            Assert.That(elementClass, Is.Not.Empty,
                "The element class was provided as an empty string.");
        });
        Assert.That(text, Is.Not.Empty, "The text was provided as an empty string.");
        var ctl = Globals.Driver.FindElements(By.ClassName(elementClass));
        Assert.That(
            ctl, Is.Not.Empty,
            "No elements with class " + elementClass + " could be found on the current page"
        );
        Assert.That(
            ctl.Count, Is.GreaterThan(0),
            "No elements with class " + elementClass + " could be found on the current page"
        );
        var foundOne = false;
        for (int i = 0; i < ctl.Count; i++)
        {
            var txt = ctl[i].Text.ToLower();
            if (txt.Contains(text.ToLower()))
            {
                foundOne = true;
            }
        }
        Assert.That(
            foundOne, Is.True,
            "The text "
                + text
                + " could not be found in any elements of the class "
                + elementClass
        );
    }
    /// <summary>
    /// Checks the an element with the tag provided contains the text provided.
    /// <summary>
    /// <param name="elementTag">The tag of the element to check.</param>
    /// <param name="text">The text of the element to check.</param>
    ///<returns>void</returns>
    public static void TagContainsText(string tag, string text)
    {
        Assert.Multiple(() =>
        {
            Assert.That(tag, Is.Not.Null, "No element tag was provided.");
            Assert.That(text, Is.Not.Null, "No text was provided.");
        });
        Assert.Multiple(() =>
        {
            Assert.That(tag, Is.Not.Empty, "The element tag was provided as an empty string.");
            Assert.That(text, Is.Not.Empty, "The text was provided as an empty string.");
        });
        var ctl = Globals.Driver.FindElements(By.TagName(tag));
        Assert.That(
            ctl.Count, Is.GreaterThan(0),
            "No elements with tag " + tag + " could be found on the current page"
        );
        var foundOne = false;
        for (int i = 0; i < ctl.Count; i++)
        {
            var txt = ctl[i].Text;
            if (txt.Contains(text))
            {
                foundOne = true;
            }
        }
        Assert.That(
            foundOne, Is.True,
            "The text " + text + " could not be found in any elements of the class " + tag
        );
    }
    /// <summary>
    /// Clicks the button with id matching that provided.
    /// <summary>
    /// <param name="id">The id of the button to click.</param>
    ///<returns>void</returns>
    public static void PressButtonWithId(string id)
    {
        Assert.That(id, Is.Not.Null, "No button id was provided.");
        Assert.That(id, Is.Not.Empty, "The button id provided was an empty string.");
        var ctl = Globals.Driver.FindElements(By.Id(id));
        Assert.That(ctl.Count, Is.GreaterThan(0), "No buttons were found matching the id " + id + ".");
        ctl[0].Click();
    }
    /// <summary>
    /// Clicks the button with class matching that provided.
    /// <summary>
    /// <param name="className">The class of the button to click.</param>
    ///<returns>void</returns>
    public static void PressButtonWithClass(string className)
    {
        Assert.That(className, Is.Not.Null, "No button class name was provided.");
        Assert.That(className, Is.Not.Empty, "The button class name provided was an empty string.");
        var ctl = Globals.Driver.FindElements(By.ClassName(className));
        Assert.That(
            ctl.Count, Is.GreaterThan(0),
            "No buttons were found matching the class " + className + "."
        );
        ctl[0].Click();
    }
    /// <summary>
    /// Raises the click event of the IWebElement pased.
    /// <summary>
    /// <param name="element">The IWebElement element to perform the click event on.</param>
    ///<returns>void</returns>
    public static void ClickOnElement(IWebElement element)
    {
        Assert.That(element, Is.Not.Null, "No element was provided.");
        element.Click();
    }
    /// <summary>
    /// Enters the provided text into an element with the provided id.
    /// <summary>
    /// <param name="id">The id of the element to enter the text into.</param>
    /// <param name="text">The text to enter into the element.</param>
    ///<returns>void</returns>
    public static void EnterTextIntoControl(string id, string text)
    {
        Assert.That(id, Is.Not.Null, "No element id was provided.");
        Assert.Multiple(() =>
        {
            Assert.That(id, Is.Not.Empty, "The element id provided was an empty string.");
            Assert.That(text, Is.Not.Null, "No text was provided to enter into the element.");
        });
        var ctl = Globals.Driver.FindElements(By.Id(id));
        Assert.That(ctl.Count, Is.GreaterThan(0), "No elements were found matching the id " + id + ".");
        ctl[0].Clear();
        ctl[0].SendKeys(text);
    }
    /// <summary>
    /// Enters the provided text into an element with the provided class name.
    /// <summary>
    /// <param name="className">The class name of the element to enter the text into.</param>
    /// <param name="text">The text to enter into the element.</param>
    ///<returns>void</returns>
    public static void EnterTextIntoControlFromClass(string className, string text)
    {
        Assert.Multiple(() =>
        {
            Assert.That(className, Is.Not.Null, "No element class name was provided.");
            Assert.That(className, Is.Not.Empty, "The element class name provided was an empty string.");
        });
        Assert.That(text, Is.Not.Null, "No text was provided to enter into the element.");
        var ctl = GetFirstElementFromClass(className);
        Assert.That(ctl, Is.Not.Null, "No elements were found matching the class name " + className + ".");
        ctl.Clear();
        ctl.SendKeys(text);
    }
    /// <summary>
    /// Checks that the text provided can be seen on the page.
    /// <summary>
    /// <param name="text">The text to search for on the page.</param>
    ///<returns>void</returns>
    public static void TestTextOnPage(string text)
    {
        Assert.That(text, Is.Not.Null, "No text was provided.");
        Assert.That(text, Is.Not.Empty, "The text provided was an empty string.");
        Globals.Driver.PageSource.Contains(text);
    }
    /// <summary>
    /// Returns a collection of elements by tag found under the element id provided.
    /// <summary>
    /// <param name="id">The element id to search from.</param>
    /// <param name="tag">The tag of the child nodes to return.</param>
    ///<returns>A collection of IWebElement objects.</returns>
    public static IEnumerable<IWebElement> GetTagsFromId(string id, string tag)
    {
        var results = Globals.Driver.FindElement(By.Id(id)).FindElements(By.TagName(tag));
        return results;
    }
    
    /// <summary>
    /// Returns a collection of elements by tag found under the element object provided.
    /// <summary>
    /// <param name="element">The element object to search from.</param>
    /// <param name="tag">The tag of the child nodes to return.</param>
    ///<returns>A collection of IWebElement objects.</returns>
    public static IEnumerable<IWebElement> GetTagsFromElement(IWebElement element, string tag)
    {
        var results = element.FindElements(By.TagName(tag));
        return results;
    }

    /// <summary>
    /// Returns a collection of elements by class name.
    /// <summary>
    /// <param name="className">The className of the child nodes to return.</param>
    ///<returns>A collection of IWebElement objects.</returns>
    public static IEnumerable<IWebElement> GetElementsByClass(string className)
    {
        var elements = Globals.Driver.FindElements(By.ClassName(className));
        return elements;
    }

    /// <summary>
    /// Returns a collection of elements by class found under the element provided.
    /// <summary>
    /// <param name="id">The element id to search from.</param>
    /// <param name="className">The class name of the child nodes to return.</param>
    ///<returns>A collection of IWebElement objects.</returns>
    public static IEnumerable<IWebElement> GetClassesFromElement(string id, string className)
    {
        var results = Globals.Driver
            .FindElement(By.Id(id))
            .FindElements(By.ClassName(className));
        return results;
    }
    /// <summary>
    /// Returns a collection of elements by class found under the element provided.
    /// <summary>
    /// <param name="element">The element to search from.</param>
    /// <param name="className">The class name of the child nodes to return.</param>
    ///<returns>A collection of IWebElement objects.</returns>
    public static IEnumerable<IWebElement> GetClassesFromElement(
        IWebElement element,
        string className
    )
    {
        var results = element.FindElements(By.ClassName(className));
        return results;
    }
    /// <summary>
    /// Returns a collection of elements by class found under the element provided.
    /// <summary>
    /// <param name="element">The element to search from.</param>
    /// <param name="className">The class name of the child nodes to return.</param>
    ///<returns>A collection of IWebElement objects.</returns>
    public static bool ElementHasClass(IWebElement element, string className)
    {
        return element.GetAttribute("class").Split(" ").ToList().Contains(className);
    }
    /// <summary>
    /// Tests that the element contains some text
    /// <summary>
    /// <param name="id">The element id to search for.</param>
    ///<returns>void</returns>
    public static void ElementContainsAnyText(string id)
    {
        Assert.That(id, Is.Not.Empty, "No id was provided for the test");
        var result = Globals.Driver.FindElement(By.Id(id)).Text;
        if (result.Length == 0)
        {
            result = Globals.Driver.FindElement(By.Id(id)).GetAttribute("value");
        }
        Assert.That(result, Is.Not.Empty, "No text was found for element id " + id);
    }
    /// <summary>
    /// Returns the element given by the id.
    /// <summary>
    /// <param name="id">The id to return the element from.</param>
    ///<returns>An IWebElement object.</returns>
    public static IWebElement GetElementFromId(string id)
    {
        var result = Globals.Driver.FindElement(By.Id(id));
        return result;
    }
    /// <summary>
    /// Returns the first element found with the class name provided.
    /// <summary>
    /// <param name="className">The class to return the first element from.</param>
    ///<returns>An IWebElement object.</returns>
    public static IWebElement GetFirstElementFromClass(string className)
    {
        var result = Globals.Driver.FindElement(By.ClassName(className));
        return result;
    }
    /// <summary>
    /// Waits for the element provided by it's id is loaded.
    /// <summary>
    /// <param name="id">The id of the element to wait for.</param>
    ///<returns>void</returns>
    public static void WaitForElementById(string id)
    {
        Globals.Wait = new OpenQA.Selenium.Support.UI.WebDriverWait(
            Globals.Driver,
            new TimeSpan(0, 0, 20)
        );
        Globals.Wait.Until(
            SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(By.Id(id))
        );
    }
    /// <summary>
    /// Waits for the first element resolved from the class provided.
    /// <summary>
    /// <param name="className">The class of the element to wait for.</param>
    ///<returns>void</returns>
    public static void WaitForElementByClass(string className)
    {
        Globals.Wait = new OpenQA.Selenium.Support.UI.WebDriverWait(
            Globals.Driver,
            new TimeSpan(0, 0, 20)
        );
        Globals.Wait.Until(
            SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(
                By.ClassName(className)
            )
        );
    }
    /// <summary>
    /// Waits for the element given by the id to not be present.
    /// <summary>
    /// <param name="id">The id of the element to disappear.</param>
    ///<returns>void</returns>
    public static void WaitForElementToDisappearById(string id)
    {
        Globals.Wait = new OpenQA.Selenium.Support.UI.WebDriverWait(
            Globals.Driver,
            new TimeSpan(0, 0, 20)
        );
        Globals.Wait.Until(
            SeleniumExtras.WaitHelpers.ExpectedConditions.InvisibilityOfElementLocated(
                By.Id(id)
            )
        );
    }
    /// <summary>
    /// Waits for the first element given by the class to not be present.
    /// <summary>
    /// <param name="className">The class of the element to disappear.</param>
    ///<returns>void</returns>
    public static void WaitForElementToDisappearByClass(string className)
    {
        Globals.Wait = new OpenQA.Selenium.Support.UI.WebDriverWait(
            Globals.Driver,
            new TimeSpan(0, 0, 20)
        );
        Globals.Wait.Until(
            SeleniumExtras.WaitHelpers.ExpectedConditions.InvisibilityOfElementLocated(
                By.ClassName(className)
            )
        );
    }
    /// <summary>
    /// Sends the provided key to the element in the UI with the current focus.
    /// <summary>
    /// <param name="key">The key to send.</param>
    ///<returns>void</returns>
    public static void SendKeys(string key)
    {
        var element = Globals.Driver.SwitchTo().ActiveElement();
        if (key.ToLower() == "tab")
        {
            element.SendKeys(Keys.Tab);
        }
        else if (key.ToLower() == "enter")
        {
            element.SendKeys(Keys.Enter);
        }
    }
    /// <summary>
    /// Sends the provided key to the provided element in the UI.
    /// <summary>
    /// <param name="element">The element to send the key stroke to.</param>
    /// <param name="key">The key to send.</param>
    ///<returns>void</returns>
    public static void SendKeys(IWebElement element, string key)
    {
        if (key.ToLower() == "tab")
        {
            element.SendKeys(Keys.Tab);
        }
        else if (key.ToLower() == "enter")
        {
            element.SendKeys(Keys.Enter);
        }
    }
    /// <summary>
    /// Validates the expected URL matches the target URL
    /// <summary>
    /// <param name="expectedUrl">The URL we are expecting.</param>
    /// <param name="tabNumber">The tab in which we want to validate the URL.</param>
    ///<returns>void</returns>
    public static void ValidateMatchingUrl(string expectedUrl, int tabNumber = 0)
    {
        Globals.Driver.SwitchTo().Window(Globals.Driver.WindowHandles[tabNumber]);
        var targetUrl = Globals.Driver.Url;
        Assert.That(
            targetUrl, Does.Contain(expectedUrl),
            $"The expected URL ({expectedUrl}) does not match the target URL ({targetUrl})"
        );
    }
    /// <summary>
    /// Scrolls to the bottom of the current page.
    /// <summary>
    ///<returns>void</returns>
    public static void ScrollToBottom()
    {
        long scrollHeight = 0;
        do
        {
            IJavaScriptExecutor js = (IJavaScriptExecutor)Globals.Driver;
            var newScrollHeight = (long)
                js.ExecuteScript(
                    "window.scrollTo(0, document.body.scrollHeight); return document.body.scrollHeight;"
                );
            if (newScrollHeight == scrollHeight)
            {
                break;
            }
            else
            {
                scrollHeight = newScrollHeight;
            }
        } while (true);
    }
    public static bool NavItemExist(string uri)
    {
        var elems = Globals.Driver.FindElements(By.TagName("a"));
        for (int i = 0; i < elems.Count; i++)
        {
            var href = elems[i].GetAttribute("href");
            if (href != null)
            {
                if (href.Contains(uri))
                {
                    return true;
                }
            }
        }
        return false;
    }
    /// <summary>
    /// Check web element visibility.
    /// <summary>
    /// <param name="id">The id of an element for checking visibility.</param>
    ///<returns>bool</returns>
    public static bool IsElementVisibleById(string id)
    {
        Assert.That(id, Is.Not.Null, "No id was provided.");
        Assert.That(id,Is.Empty, "The id was provided as an empty string.");
        var elem = Globals.Driver.FindElement(By.Id(id));
        return elem.Displayed;
    }
    /// <summary>
    /// Check web element visibility.
    /// <summary>
    /// <param name="name">The class name of an element for checking visibility.</param>
    ///<returns>bool</returns>
    public static bool IsElementVisibleByClass(string name)
    {
        Assert.That(name, Is.Not.Null, "No class name was provided.");
        Assert.That(name, Is.Not.Empty, "The class name was provided as an empty string.");
        var elem = Globals.Driver.FindElement(By.ClassName(name));
        return elem.Displayed;
    }
    /// <summary>
    /// change permission in the Security page.
    /// <summary>
    /// <param name="rowText">The element to send the key stroke to.</param>
    /// <param name="tablePage">The right page that the entity is located.</param>
    /// <param name="switchOn">switch on or off.</param>
    ///<returns>void</returns>
    public static void SwitchOnOffPermission(string rowText, string tablePage, bool switchOn)
    {
        NavigateTo("security");
        PressButtonWithId("PermissionsPage");
        PressButtonWithId("firstPagepermissionsTable");
        switch (tablePage)
        {
            case "first":
                PressButtonWithId("firstPagepermissionsTable");
                break;
            case "next":
                PressButtonWithId("nextPagepermissionsTable");
                break;
            case "last":
                PressButtonWithId("lastPagepermissionsTable");
                break;
        }
        var elements = GetTagsFromId("permissionsTable", "tr");
        foreach (var element in elements)
        {
            if (element.Text.Contains(rowText))
            {
                ClickOnElement(element);
                break;
            }
        }
        var collapseButton = GetElementFromId(
            "collapseButton-sectionPermissionRoleMembers"
        );
        if (collapseButton.GetAttribute("class").Contains("collapsed"))
        {
            PressButtonWithId("collapseButton-sectionPermissionRoleMembers");
        }
        var cells = GetTagsFromId("permissionRolesTable", "td");
        var cellsArray = cells.ToArray();
        var allowedButton = GetTagsFromElement(cellsArray[1], "div").ToArray()[
            0
        ];
        Assert.That(allowedButton, Is.Not.Null, "Could not find allowed button for target role row");
        var switchDiv = switchOn
            ? GetClassesFromElement(allowedButton, "clickableElement").Last()
            : GetClassesFromElement(allowedButton, "clickableElement").First();
        if (switchDiv != null)
        {
            ClickOnElement(switchDiv);
        }
    }
}
