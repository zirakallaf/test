### Ignored Test Scarios

Test scenarios that are ignored are skipped when the tests are run:

- @ignore

## Cleaning

In order to clean the solution, the bin and obj directories of the solution should be deleted. Once deleted, the following command should be run potentially twice, until there are no feedback comments reported:

```bash
dotnet clean
```

## Restoring Dependencies

The dependencies of a cleaned solution may be restored by using the following command:

```bash
dotnet restore
```

## Building

The service may be built locally using the following command:

```bash
dotnet build
```

## Running The Tests

Tests may be run using a setting to determine which environment to run the tests againt. An example for running tests against the production environment is shown below:

```code
dotnet test --settings:settings/live.runsettings
```

Tests may be run against any of the tags created with the tests. The command line below runs tests that have a tag of access against the development environment.

```code
dotnet test --settings:settings/local-chrome.runsettings --filter TestCategory=import-properties
```
