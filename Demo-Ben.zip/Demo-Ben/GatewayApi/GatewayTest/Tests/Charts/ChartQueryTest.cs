using System.Threading.Tasks;
using HotChocolate;
using HotChocolate.Execution;
using Gateway.GatewayTest.Helpers;
using Gateway.Models;
using Xunit;
using Microsoft.VisualStudio.TestPlatform.TestHost;

namespace Gateway.GatewayTest;

public class ChartQueryTest : BaseClassTests
{
    public ChartQueryTest(TestingWebAppFactory<Program> factory)
        : base(factory) { }

    [Theory]
    [InlineData(1, 1, "Test Name", "Test description", 150, 105, 10, 1)]
    public async Task Get_Chart_Query_NoError(
        int id,
        int clientId,
        string name,
        string description,
        int total,
        int subTotal,
        int tax,
        int status
    )
    {
        // Arrange';
        var query =
            @"query {
                charts {
                    id
                    clientId    
                    name
                    description
                    total
                    subTotal
                    tax
                    status
                }
            }";
        var request = QueryRequestBuilder.New().SetQuery(query).Create();

        // Act
        var client = this.TestServer();
        var response = await client.ExecuteRequestAsync(request);

        var json = response.ToJson();
        var result = new GqlResult<Chart>(json, "charts");

        // Assert
        Assert.True(result.Data.ClientId == clientId);
        Assert.True(result.Data.Id == id);
        Assert.True(result.Data.Name == name);
        Assert.True(result.Data.Description == description);
        Assert.True(result.Data.Total == total);
        Assert.True(result.Data.SubTotal == subTotal);
        Assert.True(result.Data.Tax == tax);
        Assert.True(result.Data.Status == status);
    }

    [Fact]
    public async Task Get_Categories_Query_NoError()
    {
        // Arrange';
        var query =
            @"query {
                charts{
                    id
                    clientId    
                    name
                    description
                    total
                    subTotal
                    tax
                    status
                }
            }";
        var request = QueryRequestBuilder.New().SetQuery(query).Create();

        // Act
        var client = this.TestServer();
        var response = await client.ExecuteRequestAsync(request);

        var json = response.ToJson();
        var result = new GqlResultList<Chart>(json, "charts");

        // Assert
        // Assert.Null(response.Errors);
        Assert.True(result.Data.Count > 0);
    }
}
