using System.Threading.Tasks;
using HotChocolate.Execution;
using Microsoft.Extensions.DependencyInjection;
using Gateway.Services;
using Gateway.Models;
using Gateway.GraphQL;
using Xunit;
using Microsoft.Extensions.Configuration;
using System.IO;
using Newtonsoft.Json;
using HotChocolate;
using Gateway.Models;
using System.Collections.Generic;
using Gateway.Graphql;

namespace Gateway.GatewayTest;

// https://stackoverflow.com/questions/57331395/net-core-execute-all-dependency-injection-in-xunit-test-for-appservice-reposit
// https://visualstudiomagazine.com/articles/2017/07/01/testserver.aspx
// https://www.c-sharpcorner.com/article/implement-functional-tests-in-net-with-xunit/

public class MutationTest
{
    [Fact]
    public async Task AddAuthor_PerformMutation_NoError()
    {
        // Arrange
        var query = "test";
        // @"mutation SaveProduct1Test {
        //   saveProduct1(input: {id:1, name:""test""}) {
        //     id
        //     name
        //   }
        // }";
        var request = QueryRequestBuilder.New().SetQuery(query).Create();

        IConfigurationBuilder configBuilder = new ConfigurationBuilder()
            .SetBasePath(Directory.GetCurrentDirectory())
            .AddJsonFile("appsettings.json");
        IConfiguration config = configBuilder.Build();

        var graphQlServer = new ServiceCollection()
            .AddSingleton<IConfiguration>(config)
            .AddHttpClient()
            .AddSingleton<ChartService>()
            .AddGraphQLServer()
            .AddQueryType(q => q.Name("Query"))
            .AddTypeExtension<ChartQuery>()
            .AddMutationType(q => q.Name("Mutation"))
            .AddTypeExtension<ChartMutation>()
            .AddInMemorySubscriptions()
            .AddSubscriptionType<ChartSubscription>();

        // Act
        //var temp = await _client.SendAsync(request);
        var response = await graphQlServer.ExecuteRequestAsync(request);

        // Assert
        // Assert.Null(response.Errors);
    }

    [Fact]
    public async Task Get_Categories_Query_NoError1()
    {
        // Arrange';
        var query =
            @"query {
                categories(cid: 1, lang: ""en"" status: ""100"") {
                    id
                    clientId
                    name
                    description
                    code
                    color
                    path
                    status
                }
            }";
        var request = QueryRequestBuilder.New().SetQuery(query).Create();

        // Act
        IConfigurationBuilder configBuilder = new ConfigurationBuilder()
            .SetBasePath(Directory.GetCurrentDirectory())
            .AddJsonFile("appsettings.json");
        IConfiguration config = configBuilder.Build();

        var graphQlServer = new ServiceCollection()
            .AddSingleton<IConfiguration>(config)
            .AddHttpClient()
            .AddSingleton<ChartService>()
            .AddGraphQLServer()
            .AddQueryType(q => q.Name("Query"))
            .AddTypeExtension<ChartQuery>()
            .AddMutationType(q => q.Name("Mutation"))
            .AddTypeExtension<ChartMutation>()
            .AddInMemorySubscriptions()
            .AddSubscriptionType<ChartSubscription>();

        var response = await graphQlServer.ExecuteRequestAsync(request);
        var json = response.ToJson();
        var result = JsonConvert.DeserializeObject<RootResponseList>(json);
        var actual = result?.data.charts;
        // Assert
        // Assert.Null(response.Errors);
        Assert.True(actual?.Count > 0);
    }

    public class RootResponseList
    {
        public DataList data { get; set; } = default!;
    }

    public class RootResponse
    {
        public Data data { get; set; } = default!;
    }

    public class Data
    {
        public Chart chart { get; set; } = default!;
    }

    public class DataList
    {
        public List<Chart> charts { get; set; } = default!;
    }
}
