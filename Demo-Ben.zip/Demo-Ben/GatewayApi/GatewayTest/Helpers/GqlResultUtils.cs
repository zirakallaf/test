using System.Collections.Generic;
using Newtonsoft.Json.Linq;

namespace Gateway.GatewayTest.Helpers;

public class GraphQLError
{
    public string Key { get; set; } = default!;
    public string Value { get; set; } = default!;
}

public class GqlResult<T>
{
    public GqlResult(string serviceResultJson, string queryName)
    {
        var rawResultJObject = JObject.Parse(serviceResultJson);
        var dataJObject = rawResultJObject["data"];
        Data = dataJObject == null ? default(T) : dataJObject[queryName].ToObject<T>();
        var graphQLErrorsJArray = (JArray)rawResultJObject["graphQLErrors"];
        GraphQLError =
            graphQLErrorsJArray == null
                ? null
                : graphQLErrorsJArray.ToObject<IList<GraphQLError>>()[0];
    }

    public T Data { get; set; }
    public GraphQLError GraphQLError { get; set; }
}

public class GqlResultList<T>
{
    public GqlResultList(string serviceResultJson, string queryName)
    {
        var rawResultJObject = JObject.Parse(serviceResultJson);

        var dataJObject = rawResultJObject["data"];
        var dataArray =
            dataJObject == null ? new JArray() : (JArray)rawResultJObject["data"][queryName];
        Data = dataArray.ToObject<IList<T>>();
        var graphQLErrorsJArray = (JArray)rawResultJObject["graphQLErrors"];
        GraphQLError =
            graphQLErrorsJArray == null
                ? null
                : graphQLErrorsJArray.ToObject<IList<GraphQLError>>()[0];
    }

    public IList<T> Data { get; set; }
    public GraphQLError GraphQLError { get; set; }
}
