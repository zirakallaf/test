using Microsoft.AspNetCore;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.TestHost;
using Microsoft.Extensions.Configuration;
using Microsoft.VisualStudio.TestPlatform.TestHost;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.IO;
using System.Net.Http;

namespace Gateway.GatewayTest.Helpers;

public class TestClassFixture : IDisposable
{
    public TestServer Server { get; set; }
    public HttpClient Client { get; set; }

    public TestClassFixture()
    {
        var webHostBuilder = WebHost.CreateDefaultBuilder();
        webHostBuilder.UseDefaultServiceProvider(options => options.ValidateScopes = false);
        webHostBuilder.UseEnvironment("Development");

        webHostBuilder.ConfigureAppConfiguration(
            (builderContext, config) =>
            {
                config.SetBasePath(Directory.GetCurrentDirectory());
                config
                    .AddJsonFile(
                        $"appsettings.Development.json",
                        optional: false,
                        reloadOnChange: true
                    )
                    .AddEnvironmentVariables();
            }
        );

        Server = new TestServer(webHostBuilder.UseStartup<Program>());
        Client = Server.CreateClient();
    }

    public void Dispose()
    {
        Client.Dispose();
        Server.Dispose();
    }
}
