using System.Threading.Tasks;
using HotChocolate.Execution.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Gateway.Services;
using Gateway.GraphQL;
using Gateway.GatewayTest.Helpers;
using System.Net.Http;
using Xunit;
using Microsoft.Extensions.Configuration;
using System.IO;
using Gateway.GatewayTest.Helpers;
using Microsoft.VisualStudio.TestPlatform.TestHost;
using Gateway.Models;
using Gateway.Graphql;

namespace Gateway.GatewayTest.Helpers;

public class BaseClassTests : IClassFixture<TestingWebAppFactory<Program>>
{
    private readonly TestingWebAppFactory<Program> _factory;

    public BaseClassTests(TestingWebAppFactory<Program> factory)
    {
        _factory = factory;
    }

    public IRequestExecutorBuilder TestServer()
    {
        IConfigurationBuilder configBuilder = new ConfigurationBuilder()
            .SetBasePath(Directory.GetCurrentDirectory())
            .AddJsonFile("appsettings.json");
        IConfiguration config = configBuilder.Build();

        var graphQlServer = new ServiceCollection()
            .AddSingleton<IConfiguration>(config)
            .AddHttpClient()
            .AddSingleton<ChartService>()
            .AddGraphQLServer()
            .AddQueryType(q => q.Name("Query"))
            .AddTypeExtension<ChartQuery>()
            .AddMutationType(q => q.Name("Mutation"))
            .AddTypeExtension<ChartMutation>()
            .AddInMemorySubscriptions()
            .AddSubscriptionType<ChartSubscription>();

        return graphQlServer;
    }
}
