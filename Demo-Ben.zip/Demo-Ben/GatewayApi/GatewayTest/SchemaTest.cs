using System.Threading.Tasks;
using HotChocolate.Execution;
using Microsoft.Extensions.DependencyInjection;
using Gateway.Services;
using Gateway.GraphQL;
using Snapshooter.Xunit;
using Xunit;
using Gateway.Graphql;

namespace Gateway.GatewayTest.Test;

public class SchemaTest
{
    [Fact]
    public async Task GenerateSchema_MatchesExistingSnapshot()
    {
        // Arrange
        var schema = await new ServiceCollection()
            .AddSingleton<ChartService>()
            .AddGraphQLServer()
            .AddQueryType(q => q.Name("Query"))
            .AddTypeExtension<ChartQuery>()
            .AddMutationType(q => q.Name("Mutation"))
            .AddTypeExtension<ChartMutation>()
            .BuildSchemaAsync();

        // Act & Assert
        schema.ToString().MatchSnapshot();
    }
}
