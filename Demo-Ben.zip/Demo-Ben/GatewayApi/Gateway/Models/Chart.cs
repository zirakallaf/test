namespace Gateway.Models;

public record Chart(
    int Id,
    int ClientId,
    string Name,
    string Description,
    int Total,
    int SubTotal,
    int Tax,
    int Status
)
{
    Chart()
        : this(default, default, default!, default!, default, default, default, default) { }
}
