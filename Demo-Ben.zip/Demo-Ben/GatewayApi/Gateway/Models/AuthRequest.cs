namespace Gateway.Models;

public record AuthRequest(
    string RequestToken,
    string RequestingUser,
    string username,
    string password
)
{
    AuthRequest()
        : this(default!, default!, default!, default!) { }
}
