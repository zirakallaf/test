namespace Gateway.Models;

public record GraphQLBodyRequest(
    string OperationName,
    string Query,
    Dictionary<string, string> Variables
)
{
    GraphQLBodyRequest()
        : this(default!, default!, default!) { }
}
