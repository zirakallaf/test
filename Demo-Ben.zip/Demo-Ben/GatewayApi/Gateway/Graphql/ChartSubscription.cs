using Gateway.Models;

namespace Gateway.GraphQL;

// [ExtendObjectType(Name = "Subscription")]
public class ChartSubscription
{
    [Topic]
    [Subscribe]
    public Chart ChartAdded([EventMessage] Chart chart) => chart;
}
