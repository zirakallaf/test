using Gateway.Models;
using Gateway.Services;
using HotChocolate.Subscriptions;

namespace Gateway.GraphQL;

[ExtendObjectType(Name = "Mutation")]
public class ChartMutation
{
    public async Task<int> SaveChart(
        Chart input,
        [Service] ChartService chartService,
        [Service] ITopicEventSender topicEventSender
    )
    {
        var rtnCategory = await chartService.SaveChart(input);
        return rtnCategory;
    }
}
