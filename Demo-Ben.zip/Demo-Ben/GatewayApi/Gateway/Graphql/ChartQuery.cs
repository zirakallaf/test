using Gateway.Models;
using Gateway.Services;

namespace Gateway.Graphql;

[ExtendObjectType(Name = "Query")]
public class ChartQuery
{
    public Task<List<Chart>> GetCharts([Service] ChartService chartService) =>
        chartService.GetCharts();
}
