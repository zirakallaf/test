using Gateway.Graphql;
using Gateway.GraphQL;
using Gateway.Middleware;
using Gateway.Services;
using Microsoft.Extensions.DependencyInjection.Extensions;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllers();

builder.Services.AddCors(options =>
{
    options.AddDefaultPolicy(policy =>
    {
        // policy.WithOrigins(configuration["AllowedOrigins"])
        policy
            .AllowAnyMethod()
            .AllowAnyHeader()
            .SetIsOriginAllowed(origin => true) // allow any origin
            .AllowCredentials();
    });
});

// builder.Services.AddSingleton<IHttpClientFactory>(new TestClientFactory(...));
// Add HttpClientFactory service to the container.
builder.Services.AddHttpClient();

builder.Services.TryAddSingleton<IHttpContextAccessor, HttpContextAccessor>();

builder.Services.AddTransient<AuthValidationMiddleware>();

// builder.Services.AddTransient<PermissionValidationMiddleware>();

// Configure hotchocolate graphql
builder.Services
    .AddTransient<ChartService>()
    .AddGraphQLServer()
    .AddQueryType(q => q.Name("Query"))
    .AddTypeExtension<ChartQuery>()
    .AddMutationType(q => q.Name("Mutation"))
    .AddTypeExtension<ChartMutation>()
    .AddInMemorySubscriptions()
    // .AddSubscriptionType(q => q.Name("Subscription"))
    .AddSubscriptionType<ChartSubscription>();

var app = builder.Build();

// register webhook
app.UseWebSockets();

// map graphsql
app.MapGraphQL();

// configure isalive
app.MapGet("/", () => true);
app.MapGet("/api/v1/isalive", () => true);

app.UseCors();

// app.UseHttpsRedirection();
// app.UseMiddleware<AuthValidationMiddleware>();
// app.UseMiddleware<PermissionValidationMiddleware>();
// app.UseAuthorization();
app.MapControllers();
app.Run();
