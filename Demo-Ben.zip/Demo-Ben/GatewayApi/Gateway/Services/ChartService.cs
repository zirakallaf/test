using Gateway.Models;

namespace Gateway.Services;

public class ChartService
{
    public async Task<List<Chart>> GetCharts(int? id = 0)
    {
        var charts = new List<Chart>
        {
            new(1, 1, "Test name", "Test Description", 1, 100, 10, 150),
            new(1, 1, "Test name", "Test Description", 1, 100, 10, 150),
        };

        return charts;
    }

    public async Task<int> SaveChart(Chart chart)
    {
        var charts = new List<Chart> { chart };

        return 1;
    }
}
