using Gateway.Models;
using Newtonsoft.Json;
using System.Text;

namespace Gateway.Middleware;

public class AuthValidationMiddleware : IMiddleware
{
    private readonly string _authProvider;

    public AuthValidationMiddleware(IConfiguration configuration)
    {
        _authProvider = configuration["Services:AuthServiceUrl"];
    }

    public async Task InvokeAsync(HttpContext context, RequestDelegate next)
    {
        try
        {
            string path = "";
            if (!string.IsNullOrEmpty(context.Request.Path.Value))
            {
                path = context.Request.Path.Value.ToLower();
            }
            string method = context.Request.Method.ToLower();

            if (
                path.Equals("/")
                || path.ToLower().EndsWith("/isalive")
                || path.ToLower().EndsWith("encryption/token")
            )
            {
                await next(context);
                return;
            }

            string token = context.Request.Headers["Authorization"].ToString();
            if (
                !context.Request.Headers.ContainsKey("Refresh")
                || !context.Request.Headers.ContainsKey("Authorization")
            )
            {
                //_logger.Warning("Request {request} missing headers", next.ToString());
                context.Response.StatusCode = StatusCodes.Status401Unauthorized;
                return;
            }

            string jsonObject = JsonConvert.SerializeObject(new AuthRequest("", "", "", ""));
            string returnValue = string.Empty;

            using (HttpClient _client = new HttpClient())
            {
                _client.DefaultRequestHeaders.Add(
                    "Refresh",
                    context.Request.Headers["Refresh"].ToString()
                );
                _client.DefaultRequestHeaders.Add(
                    "Authorization",
                    context.Request.Headers["Authorization"].ToString()
                );

                HttpResponseMessage response = await _client.PostAsync(
                    $"{_authProvider}systemauthentication",
                    new StringContent(jsonObject, Encoding.UTF8, "application/json")
                );
                if (response.IsSuccessStatusCode)
                {
                    await next(context);
                    return;
                }
                else
                {
                    //_logger.Warning("Could not validate passthrough request status code : {statusCode}", response.StatusCode);
                }
            }
        }
        catch (Exception ex)
        {
            // logger.Error(ex.Message);
        }
        context.Response.StatusCode = StatusCodes.Status401Unauthorized;
        return;
    }
}
