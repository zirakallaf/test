// using Newtonsoft.Json;
// using System.Text;

// namespace Gateway.Middleware;

// /// <summary>
// /// The middleware that catches all requests and confirms the username and token against the authorisation server
// /// </summary>
// public class PermissionValidationMiddleware : IMiddleware
// {
//     /// <summary>
//     /// The root url for the permissions service
//     /// </summary>
//     private readonly string permissionsService;

//     /// <summary>
//     /// The logging instance
//     /// </summary>
//     private readonly ILogger<PermissionValidationMiddleware> logger;

//     /// <summary>
//     /// Override to inject the configuration and logger objects
//     /// </summary>
//     public PermissionValidationMiddleware(
//         IConfiguration configuration,
//         ILogger<PermissionValidationMiddleware> logger
//     )
//     {
//         permissionsService = configuration["services:PermissionsServiceUrl"];
//         this.logger = logger;
//     }

//     /// <summary>
//     /// Invoked on any api call with the context of the call.
//     /// On success, the next delegate is invoked.
//     /// </summary>
//     /// <param name="context">The api call context</param>
//     /// <param name="next">The next delegate invoked on success</param>
//     public async Task InvokeAsync(HttpContext context, RequestDelegate next)
//     {
//         try
//         {
//             string path = "";
//             string method = context.Request.Method.ToLower();
//             context.Request.EnableBuffering();
//             using var reader = new StreamReader(context.Request.Body);
//             var requestBody = await reader.ReadToEndAsync();
//             var body = JsonConvert.DeserializeObject<GraphQLBodyRequest>(requestBody);
//             if (!string.IsNullOrEmpty(context.Request.Path.Value))
//             {
//                 path = context.Request.Path.Value.ToLower();
//                 if (path.ToLower().EndsWith("/graphql"))
//                 {
//                     if (body != null)
//                     {
//                         path = $"graphql/{body.OperationName}";
//                     }
//                 }
//             }
//             context.Request.Body.Seek(0, SeekOrigin.Begin);
//             int loggedInAs = -1;
//             var request = context.Request.QueryString;
//             if (
//                 path.Equals("/")
//                 || path.ToLower().EndsWith("/isalive")
//                 || path.ToLower().EndsWith("/graphql/")
//                 || path.ToLower().Contains("userbyusername")
//                 || path.ToLower().EndsWith("userbyids")
//                 || path.ToLower().EndsWith("viewassignedpermissions")
//                 || path.ToLower().EndsWith("encryption/token")
//                 || path.ToLower().EndsWith("/requestaccess")
//                 || path.ToLower().Contains("/requestinguser")
//                 || path.ToLower().Contains("/referencedata")
//                 || path.ToLower().Contains("/admin/")
//             )
//             {
//                 await next(context);
//                 return;
//             }
//             // This should be locked down to only login and the first user info get call.
//             // TODO At present, many calls do not have the logged in user header. This need to be recitified.
//             if (!context.Request.Headers.ContainsKey("LoggedInAs"))
//             {
//                 logger.LogInformation(
//                     "PermissionValidationMiddleware no request LoggedInAs header {0}",
//                     next.ToString()
//                 );
//                 await next(context);
//                 return;
//             }
//             else
//             {
//                 if (!int.TryParse(context.Request.Headers["LoggedInAs"].ToString(), out loggedInAs))
//                 {
//                     logger.LogInformation(
//                         "PermissionValidationMiddleware LoggedInAs value not an integer: {0}",
//                         context.Request.Headers["LoggedInAs"].ToString()
//                     );
//                     // TODO We have some calls being made before the UID is resolved. This should be rectified.
//                     /*
//                     if (context.Request.Headers["LoggedInAs"].ToString() != "undefined") {
//                         context.Response.StatusCode = 440;
//                         return;
//                     }
//                     */
//                     await next(context);
//                     return;
//                 }
//             }

//             using (HttpClient _client = new HttpClient())
//             {
//                 var jsonObject = String.Concat(
//                     "{\"url\":\"",
//                     path,
//                     "\", \"method\":\"",
//                     method,
//                     "\"}"
//                 );
//                 _client.DefaultRequestHeaders.Add("LoggedInAs", loggedInAs.ToString());
//                 if (context.Request.Headers.ContainsKey("CustomerId"))
//                     _client.DefaultRequestHeaders.Add(
//                         "CustomerId",
//                         context.Request.Headers["CustomerId"].ToString()
//                     );
//                 logger.LogInformation(
//                     "PermissionValidationMiddleware about to post {0} to {1}checkpermission",
//                     jsonObject,
//                     permissionsService
//                 );
//                 HttpResponseMessage response = await _client.PostAsync(
//                     $"{permissionsService}checkpermission",
//                     new StringContent(jsonObject, Encoding.UTF8, "application/json")
//                 );

//                 if (response.IsSuccessStatusCode)
//                 {
//                     await next(context);
//                     return;
//                 }
//                 else
//                 {
//                     logger.LogWarning(
//                         "Could not validate permissions passthrough request status code : {statusCode}",
//                         response.StatusCode
//                     );
//                     context.Response.StatusCode = 440;
//                     return;
//                 }
//             }
//         }
//         catch (Exception ex)
//         {
//             logger.LogError(
//                 "The PermissionValidationMiddleware failed with the following message: {0}",
//                 ex.Message
//             );
//         }

//         context.Response.StatusCode = 440;
//         return;
//     }
// }
