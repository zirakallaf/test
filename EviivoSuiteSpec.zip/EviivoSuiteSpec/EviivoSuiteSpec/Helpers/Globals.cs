using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;

namespace Eviivo.Suite.Helpers
{
    /// <summary>
    /// The main class for the global parameters used in the Selenium test project.
    /// <summary>
    public static class Globals
    {

        /// <summary>
        /// The main webdriver instance that is used for all the tests.
        /// <summary>
        public static IWebDriver Driver;
        
        /// <summary>
        /// The wait parameter used to initiate delays between tests.
        /// <summary>
        public static WebDriverWait Wait;

        /// <summary>
        /// Stored details of the columns in a table row for use in tests
        /// </summary>
        public static string[] RowRecord;
    }
}

