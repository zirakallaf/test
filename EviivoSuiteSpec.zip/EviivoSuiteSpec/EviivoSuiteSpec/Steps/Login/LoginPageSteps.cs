using NUnit.Framework;
using TechTalk.SpecFlow;
using Eviivo.Suite.Helpers;

namespace Eviivo.Suite.Steps
{
    [Binding]
    public class LoginPageSteps
    {
        [Then(@"I should see the main login page")]
        public void ThenIShouldSeeTheMainLoginPage()
        {
            SeleniumHelper.WaitForElementByClass("loadingContainer");
            // SeleniumHelper.TestPageTitle("ICON Portal - Login Page");
        }

        [When(@"I press the login button")]
        public void WhenIPressTheLoginButton()
        {
            SeleniumHelper.PressButtonWithId("btnLogin");
        }

        [When(@"I press the reset password button")]
        public void WhenIPressTheResetPasswordButton()
        {
            SeleniumHelper.PressButtonWithId("btnMoveLeft");
            // To allow the transition to complete and the text to be populated.
            SeleniumHelper.WaitForElementByClass("loginFPTitle");
        }

        [When(@"I press the move to request access button")]
        public void WhenIPressTheMoveToRequestAccessButton()
        {
            SeleniumHelper.PressButtonWithId("btnMoveLeftBottom");
            // To allow the transition to complete and the text to be populated.
            SeleniumHelper.WaitForElementByClass("loginPanelRightRA");
        }

        [Then(@"I should see the login heading ""(.*)""")]
        public void ThenIShouldSeeTheLoginHeading(string title)
        {
            Assert.IsTrue(title.Length > 0);
            SeleniumHelper.ClassContainsText("loginTitle", title);
        }

        [Then(@"I should see the login into the icon portal heading ""(.*)""")]
        public void ThenIShouldSeeTheLoginIntoTheIconPortalHeading(string title)
        {
            Assert.IsTrue(title.Length > 0);
            SeleniumHelper.ClassContainsText("sectionTitle", title);
        }

        [Then(@"I should see the cannot gain access heading ""(.*)""")]
        public void ThenIShouldSeeTheCannotGainAccessHeading(string title)
        {
            Assert.IsTrue(title.Length > 0);
            SeleniumHelper.ClassContainsText("sectionTitle", title);
        }

        [Then(@"I should see the request access heading ""(.*)""")]
        public void ThenIShouldSeeTheRequestAccessHeading(string title)
        {
            Assert.IsTrue(title.Length > 0);
            SeleniumHelper.ClassContainsText("loginPanelRightRA", title);
        }

        [Then(@"I should see the access request text ""(.*)""")]
        public void ThenIShouldSeeTheAccessRequestText(string title)
        {
            Assert.IsTrue(title.Length > 0);
            SeleniumHelper.ClassContainsText("sectionText", title);
        }

        [Then(@"I should see the forgotten password heading ""(.*)""")]
        public void ThenIShouldSeeTheForgottenPasswordHeading(string title)
        {
            Assert.IsTrue(title.Length > 0);
            SeleniumHelper.ClassContainsText("sectionTitle", title);
        }

        [Then(@"I should see a forgotten password heading ""(.*)""")]
        public void ThenIShouldSeeAForgottenPasswordHeading(string title)
        {
            Assert.IsTrue(title.Length > 0);
            SeleniumHelper.ClassContainsText("loginFPTitle", title);
        }

        [Then(@"I should see the forgotten password text ""(.*)""")]
        public void ThenIShouldSeeTheForgottenPasswordText(string title)
        {
            Assert.IsTrue(title.Length > 0);
            SeleniumHelper.ClassContainsText("sectionText", title);
        }

        [Then(@"I should see the move to the login information text ""(.*)""")]
        public void ThenIShouldSeeTheMoveToTheLoginInformationText(string title)
        {
            Assert.IsTrue(title.Length > 0);
            SeleniumHelper.ClassContainsText("sectionText", title);
        }

        [Then(@"I should see the forgotten password information ""(.*)""")]
        public void ThenIShouldSeeTheForgottenPasswordInformation(string title)
        {
            Assert.IsTrue(title.Length > 0);
            SeleniumHelper.ClassContainsText("fpwInformationText", title);
        }

        [When(@"I should see the request access information ""(.*)""")]
        [Then(@"I should see the request access information ""(.*)""")]
        public void ThenIShouldSeeTheRequestAccessInformation(string title)
        {
            Assert.IsTrue(title.Length > 0);
            SeleniumHelper.ClassContainsText("requestAccessIntro", title);
        }

        [Then(@"I should see the login button with text ""(.*)""")]
        public void ThenIShouldSeeTheLoginButtonWithText(string title)
        {
            Assert.IsTrue(title.Length > 0);
            SeleniumHelper.ClassContainsText("loginButton", title);
        }

        [Then(@"I should see the move to login button with text ""(.*)""")]
        public void ThenIShouldSeeTheMOveTOLoginButtonWithText(string title)
        {
            Assert.IsTrue(title.Length > 0);
            SeleniumHelper.ElementContainsText("btnMoveRight", title);
        }

        [Then(@"I should see the forgotten password button with text ""(.*)""")]
        public void ThenIShouldSeeTheFoprgottenPasswordButtonWithText(string title)
        {
            Assert.IsTrue(title.Length > 0);
            SeleniumHelper.ClassContainsText("sectionButton", title);
        }

        [Then(@"I should see the move to request access button with text ""(.*)""")]
        public void ThenIShouldSeeTheMoveToRequestAccessButtonWithText(string title)
        {
            Assert.IsTrue(title.Length > 0);
            SeleniumHelper.ClassContainsText("sectionButton", title);
        }

        [Then(@"I should see the request access button with text ""(.*)""")]
        public void ThenIShouldSeeTheRequestAccessButtonWithText(string title)
        {
            Assert.IsTrue(title.Length > 0);
            SeleniumHelper.ElementContainsText("btnRquestAccess", title);
        }
    }
}
