using System;
using NUnit.Framework;
using TechTalk.SpecFlow;
using System.Collections.Generic;
using Eviivo.Suite.Helpers;
using System.Threading;
using System.Linq;
using OpenQA.Selenium;

namespace Eviivo.Suite.Steps
{
    /// <summary>
    /// Class to contain the steps that are used in common between all tests.
    /// </summary>
    [Binding]
    public class GeneralSteps
    {
        /// <summary>
        /// Variable to hold the scenario context for test interrogation.
        /// </summary>
        private readonly ScenarioContext _scenarioContext;

        /// <summary>
        /// Default site hit if no setting file is set.
        /// </summary>
        private readonly string defaultRoot = "http://localhost:4200/";

        /// <summary>
        /// Default browser used if no setting file is set.
        /// </summary>
        private readonly string defaultBrowser = "Chrome";

        /// <summary>
        /// Class override setting the scenario context.
        /// </summary>
        public GeneralSteps(ScenarioContext scenarioContext)
        {
            _scenarioContext = scenarioContext;
        }

        #region " Given "

        [Given(@"I have a browser window")]
        public void GivenIHaveABrowserWindow()
        {
            Assert.IsTrue(SeleniumHelper.HasBrowserDriver());
        }

        [Given(@"I have logged in as ""(.*)"" with password ""(.*)""")]
        [When(@"I log in as ""(.*)"" with password ""(.*)""")]
        public void GivenIHaveLoggedInWithPassword(string username, string password)
        {
            string root = TestContext.Parameters["baseURL"] ?? defaultRoot;
            SeleniumHelper.GotoURL(root);
            SeleniumHelper.EnterTextIntoControl("txtUsername", username);
            SeleniumHelper.EnterTextIntoControl("txtPassword", password);
            SeleniumHelper.PressButtonWithId("btnLogin");
            // // Wait for the login process to complete and the home page to load.
            // SeleniumHelper.WaitForElementByClass("v-toolbar-title");
        }

        [When(@"I log out and log in again as ""(.*)"" with password ""(.*)""")]
        public void WhenILogOutAndLogInAgainAsWithPassword(string username, string password)
        {
            WhenINavigateTo("logout");
            GivenIHaveLoggedInWithPassword(username, password);
        }

        #endregion

        #region " When "

        [When(@"I tab to the next field")]
        public void WhenITabToTheNextField()
        {
            SeleniumHelper.SendKeys("tab");
        }

        [Given(@"I access the website")]
        [When(@"I access the website")]
        public void WhenIAccessTheWebsite()
        {
            string root = TestContext.Parameters["baseURL"];
            if (root == null)
            {
                root = defaultRoot;
            }
            Assert.IsTrue(root.Length > 0);
            SeleniumHelper.GotoURL(root);
        }

        [Given(@"I navigate to ""(.*)""")]
        [When(@"I navigate to ""(.*)""")]
        public void WhenINavigateTo(string uri)
        {
            SeleniumHelper.NavigateTo(uri);
        }

        [When(@"I log out of the application")]
        public void WhenILogOutOfTheApplication()
        {
            SeleniumHelper.NavigateTo("logout");
        }

        [Given(@"I have entered ""(.*)"" into the field ""(.*)""")]
        [When(@"I have entered ""(.*)"" into the field ""(.*)""")]
        public void WhenIHaveEnteredIntoTheField(string value, string elementId)
        {
            SeleniumHelper.EnterTextIntoControl(elementId, value);
        }

        #endregion

        #region " Then "

        [Then(@"the page should have a title of ""(.*)""")]
        public void ThenThePageShouldHaveATitleOf(string title)
        {
            SeleniumHelper.TestPageTitle(title);
        }

        [Then(@"I should see an element with id ""(.*)""")]
        public void ThenIShouldSeeAnElementWithId(string id)
        {
            SeleniumHelper.TestElementById(id);
        }

        [Then(@"I should see a message saying ""(.*)""")]
        public void ThenIShouldSeeAMessageSaying(string message)
        {
            SeleniumHelper.WaitForElementByClass("v-snack__content");
            SeleniumHelper.ClassContainsText("v-snack__content", message);
        }

        [Then(@"I should see a label saying ""(.*)""")]
        public void ThenIShouldSeeALabelSaying(string txt)
        {
            SeleniumHelper.TagContainsText("label", txt);
        }

        [Then(@"I should see a ""(.*)"" heading saying ""(.*)""")]
        public void ThenIShouldSeeAHeadingSaying(string headerTag, string txt)
        {
            SeleniumHelper.TagContainsText(headerTag, txt);
        }

        #endregion



        [BeforeScenario()]
        public void StartSeleniumTest()
        {
            string browser = TestContext.Parameters["browser"];
            if (browser == null)
            {
                browser = defaultBrowser;
            }
            SeleniumHelper.SetBrowserDriver(browser);
        }

        [AfterScenario()]
        public static void EndSeleniumTest()
        {
            SeleniumHelper.CloseBrowser();
        }
    }
}
