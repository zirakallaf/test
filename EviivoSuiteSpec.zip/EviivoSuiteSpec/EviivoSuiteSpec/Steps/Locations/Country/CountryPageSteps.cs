using System;
using NUnit.Framework;
using TechTalk.SpecFlow;
using System.Collections.Generic;
using Eviivo.Suite.Helpers;
using System.Linq;

namespace Eviivo.Suite.Steps
{
    [Binding]
    public class TopLevelSiteDetailsComponentSteps
    {
        [Then(@"I should see the country name input")]
        public void ThenIShouldSeeTheCountryNameInput()
        {
            SeleniumHelper.WaitForElementToDisappearByClass("MuiDialog-paper");
            //SeleniumHelper.GetElementFromId("");
        }
    }
}
