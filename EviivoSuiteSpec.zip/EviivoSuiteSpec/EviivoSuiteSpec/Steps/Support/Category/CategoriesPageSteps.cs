using NUnit.Framework;
using TechTalk.SpecFlow;
using Eviivo.Suite.Helpers;

namespace Eviivo.Suite.Steps
{
    [Binding]
    public class CategoriesPageSteps
    {
        [Then(@"I should see the categories page")]
        public void ThenIShouldSeeTheCategoryPage()
        {
            SeleniumHelper.WaitForElementById("categorySkeletonTable");
            SeleniumHelper.ElementExists("categoryTableContainer");
        }

        [Then(@"I should see the add new category button")]
        public void ThenIShouldSeeTheAddNewCategoryButton()
        {
            SeleniumHelper.ElementExists("btnAddCategory");
        }

        [Given(@"I click on the add new category button")]
        [When(@"I click on the add new category button")]
        public void WhenIClickOnTheAddNewCategoryButton()
        {
            SeleniumHelper.PressButtonWithId("btnAddCategory");
        }

        [Given(@"I should see the add category dialogbox")]
        [Then(@"I should see the add category dialogbox")]
        public void TheIShouldSeeTheAddCategoryDialogbox()
        {
            SeleniumHelper.WaitForElementById("txtName");
            SeleniumHelper.PressButtonWithId("dialogAddCategoryContainer");
        }
    }
}
