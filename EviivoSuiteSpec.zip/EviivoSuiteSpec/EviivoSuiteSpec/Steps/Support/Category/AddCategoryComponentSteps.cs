using NUnit.Framework;
using TechTalk.SpecFlow;
using Eviivo.Suite.Helpers;

namespace Eviivo.Suite.Steps
{
    [Binding]
    public class AddCategoryComponentSteps
    {
        [Then(@"I should see the name input field")]
        public void ThenIShouldSeeTheNameInputField()
        {
            SeleniumHelper.ElementExists("txtName");
        }

        [Then(@"I should see the description input field")]
        public void ThenIShouldSeeTheDescriptionInputField()
        {
            SeleniumHelper.ElementExists("txtDescription");
        }

        [Then(@"I should see the code input field")]
        public void ThenIShouldSeeTheCodeInputField()
        {
            SeleniumHelper.ElementExists("txtCode");
        }

        [Then(@"I should see the color input field")]
        public void ThenIShouldSeeTheColorInputField()
        {
            SeleniumHelper.ElementExists("txtColor");
            SeleniumHelper.WaitForElementById("categorySkeletonTable");
        }

        [Then(@"I should see the upload image container")]
        public void ThenIShouldSeeTheUploadImageContainer()
        {
            SeleniumHelper.ElementExists("uploadImageContainer");
        }

        [Then(@"I click on the upload image")]
        public void ThenIClickOnTheUploadImage()
        {
            SeleniumHelper.PressButtonWithId("btnImageUpload");
        }

        [Given(@"I click on the Google translate button")]
        [When(@"I click on the Google translate button")]
        public void WhenIClickOnTheGoogleTranslateButton()
        {
            SeleniumHelper.PressButtonWithId("btnGoogleTranslate");
        }

        [Given(@"I click on the translate button")]
        [When(@"I click on the translate button")]
        public void WhenIClickOnTheTranslateButton()
        {
            SeleniumHelper.PressButtonWithId("btnTranslate");
        }

        [Given(@"I click on the save translation button")]
        [When(@"I click on the save translation button")]
        public void WhenIClickOnTheSaveTranslationButton()
        {
            SeleniumHelper.WaitForElementById("iconGoogleLogo");
            SeleniumHelper.PressButtonWithId("btnSaveTranslation");
        }

        [Given(@"I click on the next translation language button")]
        [When(@"I click on the next translation language button")]
        public void WhenIClickOnTheNextTranslationLanguageButton()
        {
            SeleniumHelper.PressButtonWithId("btnNextTranslation");
        }

        [Given(@"I click on the close translation dialogbox button")]
        [When(@"I click on the close translation dialogbox button")]
        public void WhenIClickOnTheCloseTranslationDialogboxButton()
        {
            SeleniumHelper.PressButtonWithId("btnCloseTranslationDialog");
        }

        [Given(@"I click on the save category button")]
        [When(@"I click on the save category button")]
        public void WhenIClickOnTheSaveCategoryButton()
        {
            SeleniumHelper.PressButtonWithId("btnSaveCategory");
        }

        [Given(@"I have selected color ""(.*)""")]
        public void GivenIHaveSelectedColor(string color)
        {
            SeleniumHelper.EnterTextIntoControl("txtColor", color);
            SeleniumHelper.PressButtonWithId("txtColor");
        }
    }
}
