using NUnit.Framework;
using TechTalk.SpecFlow;
using Eviivo.Suite.Helpers;

namespace Eviivo.Suite.Steps
{
    [Binding]
    public class SupportPageSteps
    {
        [Then(@"I should see the support page tiles")]
        public void ThenIShouldSeeTheSupportPageTiles()
        {
            SeleniumHelper.ElementExists("supportContainer");
        }

        [When(@"I click on ""(.*)"" tile")]
        public void WhenIClickOnTile(string tile)
        {
            Assert.IsNotNull(tile, "No tile string was provided.");
            Assert.AreNotEqual(
                tile,
                string.Empty,
                "The tile string was provided as an empty string."
            );
            // WaitForElementToDisappearByClass("pg-loading-center-middle");
            var container = SeleniumHelper.GetElementFromId("supportContainer");
            var elems = SeleniumHelper.GetTagsFromElement(container, "a");
            foreach (var elem in elems)
            {
                var href = elem.GetAttribute("href");
                if (href != null)
                {
                    if (href.Contains(tile))
                    {
                        elem.Click();
                        return;
                    }
                }
            }
        }
    }
}
